package com.cg.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class JspController {

	@RequestMapping("/")
	public String showAll() {
		return "index";
	}

	@RequestMapping("/payment")
	public String payment() {
		return "paymentpage1";
	}

	@RequestMapping("/credit")
	public String credit() {
		return "credit";
	}

	@RequestMapping("/netbanking")
	public String netbanking() {
		return "netbanking";
	}

	@RequestMapping("/cashondelivery")
	public String cashondelivery() {
		return "cashondelivery";
	}
	
	@RequestMapping("/tez")
	public String tez() {
		return "tez";
	}
	
	@RequestMapping("/paytm")
	public String paytm() {
		return "paytm";
	}
}
